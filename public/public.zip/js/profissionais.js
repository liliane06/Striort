const profissionais= {
    norte:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                }
            ]
        },
        {
            nome: "Acre",
            sigla: "AC",
            cidades:[                    
                {
                    cidade:'Rio Branco',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                },
                {
                    cidade:'Xapuri',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                }
            ]
        }
    ],
    nordeste:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                }
            ]
        }
    ],
    CentroOeste:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{facebook:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                }
            ]
        }
    ],
    sudeste:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                }
            ]
        }
    ],
    sul:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[{nome:'bla', 
                                tel:'1111-1111', 
                                redesSociais:[{faceboock:'bla.bla', instagram:'bla.com'}], 
                                endereco:'alamenda mamore'}
                    ]
                }
            ]
        }
    ]
}