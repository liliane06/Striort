const profissionais= {
    norte:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[
                        {nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                }
            ]
        },
        {
            nome: "Acre",
            sigla: "AC",
            cidades:[                    
                {
                    cidade:'Rio Branco',
                    esteticista:[{nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                },
                {
                    cidade:'Xapuri',
                    esteticista:[{nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                }
            ]
        }
    ],
    nordeste:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[{nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                }
            ]
        }
    ],
    CentroOeste:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{facebook:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[{nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                }
            ]
        }
    ],
    sudeste:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[
                            {nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'
                            },
                            {nome:'Nayara Andrade2', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'
                            },

                    ]
                }
            ]
        }
    ],
    sul:[
        {
            nome: "Amazonas",
            sigla: "AM",
            cidades:[                    
                {
                    cidade:'Manaus',
                    esteticista:[{nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                },
                {
                    cidade:'Amapa',
                    esteticista:[
                        {nome:'Nayara Andrade', 
                                tel:'(11)- 4534 - 4565', 
                                redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                                endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'},
                        {nome:'Nayara Andrade', 
                        tel:'(11)- 4534 - 4565', 
                        redesSociais:[{faceboock:'https://www.facebook.com/Bothanicamineral/', instagram:'https://www.instagram.com/bothanicamineral/'}], 
                        endereco:'Rua: Alameda Marmoré 503 - Alphaville | Barueri - SP'}
                    ]
                }
            ]
        }
    ]
}